OPENAI_API_KEY=sk-proj-xZSUnjIlIAt4C1rxWAQHT3BlbkFJUwozvARMQ49aZUbLNRCR
#page_title="KJ Helpdesk Automation"
#header = "KJ Helpdesk Automation"
model = "gpt-4"
temperature = "0.0"